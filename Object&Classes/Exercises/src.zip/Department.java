import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

public class Department implements Comparable<Department> {

    private String name;
    private List<Employee> employees;

    public Department(String name) {
        this.name = name;
        this.employees = new ArrayList<>();
    }

    public String getName() {
        return name;
    }

    public List<Employee> getEmployees() {
        return employees;
    }

    public double getAverageSalary() {
        return employees.stream()
                .mapToDouble(Employee::getSalary)
                .average()
                .orElse(0);
    }

    @Override
    public int compareTo(Department other) {
        return Double.compare(this.getAverageSalary(), other.getAverageSalary());
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Department that = (Department) o;
        return Objects.equals(name, that.name);
    }

    @Override
    public int hashCode() {
        return Objects.hash(name);
    }

    @Override
    public String toString() {
        return "Department " + name + '\n' +
                + getAverageSalary() + " average salary" +
                "\n" + employees;
    }
}
