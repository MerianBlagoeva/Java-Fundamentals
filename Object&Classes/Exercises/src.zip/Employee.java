public class Employee implements Comparable<Employee> {
    private String name;
    private double salary;
    private String position;
    private String department;

    public Employee(String name, double salary, String position, String department) {
        this.name = name;
        this.salary = salary;
        this.position = position;
        this.department = department;
    }

    public String getName() {
        return name;
    }

    public double getSalary() {
        return salary;
    }

    public String getPosition() {
        return position;
    }

    public String getDepartment() {
        return department;
    }

    @Override
    public int compareTo(Employee o) {
        return Double.compare(o.getSalary(), this.getSalary());
    }

    @Override
    public String toString() {
        return name + ' ' + salary + ' ' + position + ' ' + department;
    }
}
