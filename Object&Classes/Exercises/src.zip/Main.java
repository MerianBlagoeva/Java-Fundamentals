import java.util.*;
import java.util.stream.Collectors;

public class Main {
    public static void main(String[] args) {
        List<Employee> employees = new ArrayList<>();
        List<Department> departments = new ArrayList<>();
        employees.add(new Employee("John", 1000, "PR", "Sales"));
        employees.add(new Employee("Jane", 2000, "Dev", "Coding"));
        employees.add(new Employee("Jack", 3000, "Manager","Managment"));
        employees.add(new Employee("Jill", 7300, "PR", "Sales"));

        for (Employee employee : employees) {
            Optional<Department> department = departments.stream()
                    .filter(d -> d.getName().equals(employee.getDepartment()))
                    .findFirst();

            Department dep;

            if (department.isEmpty()) {
                dep = new Department(employee.getDepartment());
                departments.add(dep);
            } else {
                dep = department.get();
            }
            dep.getEmployees().add(employee);
        }

        System.out.println(departments.stream().max(Department::compareTo).get());

    }
}
